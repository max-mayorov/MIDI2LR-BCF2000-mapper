## Actual Behavior
1. 
2. 

## Expected Behavior
1. 
2. 

## Software versions
- React-Native VS Code extension version: 
- VSCode version: 
- OS platform and version: 
- React Native version: 

## Outputs (Include if relevant)
- Output of the Debug Console (View -> Toggle Debug Console): 
- Output of the React-Native output channel (View -> Toggle Output -> Select React-Native in ListBox): 
- Output of the Developer Tools console (Help -> Toggle Developer Tools -> Select Console tab): 
