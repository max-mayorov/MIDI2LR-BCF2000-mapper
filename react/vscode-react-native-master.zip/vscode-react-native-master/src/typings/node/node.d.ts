/// <reference path="../../../node_modules/vscode/typings/node.d.ts" />
