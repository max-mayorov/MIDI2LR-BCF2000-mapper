// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for details.
// This file intentionally left blank
// It is just needed to satisfy a "require.resolve"