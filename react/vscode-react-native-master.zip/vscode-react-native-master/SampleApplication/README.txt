To use the SampleApplication you first need to run on its folder:
 1. npm install react-native --save - to install the react-native dependency in the project
 2. react-native android - to recreate the Android project
 3. react-native upgrade - to recreate the iOS Project
